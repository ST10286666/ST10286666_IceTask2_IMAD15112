package com.example.icetask2guessinggame

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val DisplayView = findViewById<TextView>(R.id.DisplayView)
        val EnterNumber = findViewById<EditText>(R.id.EnterNumber)

        val Confirmbutton = findViewById<Button>(R.id.ConfirmButton)
        Confirmbutton.setOnClickListener {

        val myRandomNumber: List<Int> = List(1) { Random.nextInt(1,100)}
           Confirmbutton.setOnClickListener {
                val randomNumber = (Math.random() *100)  + 1

                val restartButton = findViewById<Button>(R.id.ResetButton)
                restartButton.setOnClickListener {
                    EnterNumber.text.clear()
                    DisplayView.text = ""
                }

                val NumberText = EnterNumber.text.toString()
                val Number = Integer.parseInt(NumberText)

                if (EnterNumber.text == myRandomNumber) {
                   DisplayView.text = "You guessed Right"
                }else if (Number < randomNumber) {
                    DisplayView.text = "your guess is to low"
                }else {
                    DisplayView.text = "your guess is to high"
                }
            }
         }
       }
    }
